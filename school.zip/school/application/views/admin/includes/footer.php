<!-- Footer line -->
    <div id="footer">
        <div class="wrapper">Copyright 2013 &copy; Xenon Tech</div>
    </div>