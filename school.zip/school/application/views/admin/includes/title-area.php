<!-- Title area -->
<div class="titleArea">
	<div class="wrapper">
		<div class="pageTitle">
			<h5><?php echo $title;?></h5>
			<span><?php echo $message;?></span>
		</div>
		<div class="middleNav">
			
			<div class="clear"></div>
		</div>
		<div class="clear"></div>
	</div>
</div>