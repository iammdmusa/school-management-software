<?php
if($attendence)
{
?>
    <input id="send_button_id"  type="button" value="Send SMS" class="redB send_button_idCSS" onclick="send_gurdian_sms1(document.forms.validate);" />
<?php
}
?>
<input type="submit" value="submit" class="redB" />