<?php
  $CI = get_instance();
  define('BASEURL', $CI->config->item('base_url'));
  define('DOC_ROOT', $CI->config->item('doc_root'));
  define('PROJECTNAME', $CI->config->item('projectname'));
  class Siteurls  {  }
?>
